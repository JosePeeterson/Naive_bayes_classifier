print('Ques2')

import sys
import math as m
import numpy as np
import operator
import matplotlib.pyplot as plt

import scipy.io
mat = scipy.io.loadmat('spamData.mat')
Xtrain = mat['Xtrain']    # 2d array
ytrain = mat['ytrain']    # 1d array
Xtest = mat['Xtest']      # 2d array
ytest = mat['ytest']      # 1d array
#print(Xtrain[12])
ytrain = list(map(int, ytrain))
ytest = list(map(int, ytest))

def ErrorRate(ytest,ytest_classified):
    """This fucntion calculates error rate"""
    map_object = map(operator.sub, ytest,ytest_classified)
    subtracted_list = list(map_object)
    error = list(map(abs, subtracted_list))
    Er = ((sum(error))/len(ytest))*100
    return Er

def log_transform(data):
    #log_data = np.where(data >= 0, log(data))
    mat = np.array(data) + 0.1
    log_data = np.log(mat)
    return log_data

def norm_pdf(x, mean, var):
    denom = (2*m.pi*var)**0.5
    num = m.exp(-(float(x)-float(mean))**2/(2*var))
    prob = num/denom
    if(prob == 0):
        prob = 0.0000000001
    return prob

def Predict_new_emails(ytrain, ytest, log_Xtrain, log_Xtest):
    """This function predicts new email as spam or non spam"""
    # lambda max likelihood calculation
    ytrain = list(map(int, ytrain))
    ytest = list(map(int, ytest))
    Tot_emails = len(ytrain)
    Num_spam = sum(ytrain, 0)
    Num_NOT_spam = Tot_emails - Num_spam
    lamb_ML = Num_spam / Tot_emails
    # print(lamb_ML)

    ytest_classified = []  # after classification of new emails
    cnt_ones_feat_cl = []  # stores either cnt_ones_feat_cl0 or cnt_ones_feat_cl1
    mean_cl0 = []  # mean of each feature in cl 0
    mean_cl1 = []  # mean of each feature in cl 1
    var_cl0 = [] # var of each feature in cl 0
    var_cl1 = []  # var of each feature in cl 1

# find the mean for each feature and each class
    for feat in range(0, len(log_Xtrain[0])):
        cnt = 0
        for s in range(0, len(log_Xtrain)):
            if (ytrain[s] == 0):
               cnt = cnt + log_Xtrain[s][feat]
        mean_cl0.append(cnt/Num_NOT_spam)

    for feat in range(0, len(log_Xtrain[0])):
        cnt = 0
        for s in range(0, len(log_Xtrain)):
            if (ytrain[s] == 1):
               cnt = cnt + log_Xtrain[s][feat]
        mean_cl1.append(cnt/Num_spam)

# find the variance for each feature and each class

    for feat in range(0, len(log_Xtrain[0])):
        cnt = 0
        for s in range(0, len(log_Xtrain)):
            if (ytrain[s] == 0):
               cnt = cnt + (log_Xtrain[s][feat] - mean_cl0[feat])**2
        var_cl0.append(cnt/Num_NOT_spam)

    for feat in range(0, len(log_Xtrain[0])):
        cnt = 0
        for s in range(0, len(log_Xtrain)):
            if (ytrain[s] == 1):
               cnt = cnt + (log_Xtrain[s][feat] - mean_cl1[feat])**2
        var_cl1.append(cnt/Num_spam)



    for n in range(0, len(ytest)):

        mean_feat_cl = mean_cl0
        var_feat_cl = var_cl0

        for op_cl in range(0, 2):
            sum_lik_prob = 0
            for feat in range(0, len(Xtrain[0])):
                lik_prob = norm_pdf(log_Xtest[n][feat], mean_feat_cl[feat], var_feat_cl[feat])
                sum_lik_prob = sum_lik_prob + m.log(lik_prob)

            if (op_cl == 0):
                Non_spam_prob = m.log(1 - lamb_ML) + sum_lik_prob
            else:
                spam_prob = m.log(lamb_ML) + sum_lik_prob

            mean_feat_cl = mean_cl1
            var_feat_cl = var_cl1

        if (spam_prob >= Non_spam_prob):
            ytest_classified.append(1)
        else:
            ytest_classified.append(0)

    return ytest_classified

ytest_classified = []
ytrain_classified = []

#data = [[1, 0.5],[0.5, 1]]
log_Xtrain = log_transform(Xtrain)
log_Xtest = log_transform(Xtest)

#print(Xtest[1500][56])
#print(log_Xtest[1500][56])

ytest_classified = Predict_new_emails(ytrain, ytest, log_Xtrain, log_Xtest)
print(ytest_classified)
Er = ErrorRate(ytest,ytest_classified)
print('Testing error = ', Er)

ytrain_classified = Predict_new_emails(ytrain, ytrain, log_Xtrain, log_Xtrain)
print(ytrain_classified)
Er = ErrorRate(ytrain,ytrain_classified)
print('Training error = ', Er)


# Testing error =  17.838541666666664
# Training error =  16.900489396411093






