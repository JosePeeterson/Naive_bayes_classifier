Please place spamdata.mat in the same folder

Run ques2 to find error rates

It takes approximate 10 minutes to run this program.