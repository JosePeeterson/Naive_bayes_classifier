print('Ques3')

import sys
import math as m
import numpy as np
import operator
import matplotlib.pyplot as plt
from operator import sub
from operator import add
from numpy.linalg import inv

import scipy.io
mat = scipy.io.loadmat('spamData.mat')
Xtrain = mat['Xtrain']    # 2d array
ytrain = mat['ytrain']    # 1d array
Xtest = mat['Xtest']      # 2d array
ytest = mat['ytest']      # 1d array
#print(Xtrain[12])
ytrain = list(map(int, ytrain))
ytest = list(map(int, ytest))

    # FUNCTION DEFINITIONS

def log_transform(data):
    #log_data = np.where(data >= 0, log(data))
    mat = np.array(data) + 0.1
    log_data = np.log(mat)
    return log_data


def ErrorRate(ytest,ytest_classified):
    """This fucntion calculates error rate"""
    map_object = map(operator.sub, ytest,ytest_classified)
    subtracted_list = list(map_object)
    error = list(map(abs, subtracted_list))
    Er = ((sum(error))/len(ytest))*100
    return Er


def mu_func(log_Xtrain_xtra,w_bold,k):
    """This function calculates mu for every sample x"""
    mu_vect = []
    a = np.array(w_bold, dtype=np.float64)  # dot product operation
    for i in range(0,len(log_Xtrain_xtra)):
        b = np.array(log_Xtrain_xtra[i], dtype=np.float64)  # dot product operation
        prod = np.dot(a,b) + k # k is used in testing only in eval_log_reg func.
        mu = 1/(1 + np.exp(-prod))  # dot product operation
        mu_vect.append(mu)
    mu_vect = np.array(mu_vect,dtype=np.float64)
    return mu_vect


def grad_reg(log_Xtrain_xtra, mu_vect, ytrain, w_bold, lamb,l):
    w_bold = np.array(w_bold, dtype=np.float64)
    w_zer_bias = w_bold # only make the bias zero for w mutliplying lamb so create seperate w_bold
    w_zer_bias[0] = 0 # Do NOT regularize the bias term
    g_k = []
    g_reg = []
    w_reg = []
    temp = list(map(sub, mu_vect, ytrain))
    c = np.array(log_Xtrain_xtra)
    for f in range(0,len(log_Xtrain_xtra[0])):
        a = np.array(temp,dtype=np.float64) # dot product operation
        b = np.array(c[:,f],dtype=np.float64) # dot product operation
        g = np.matmul(b, a)
        #g = b.dot(a) # dot product operation
        g_k.append(g)
    for i in w_zer_bias:
        w_reg.append(i * lamb[l])
    g_reg = list(map(add, g_k, w_reg))
    g_reg = np.array(g_reg,dtype=np.float64)
    return g_reg


def hessian(log_Xtrain_xtra, s_mat, lamb, l):

    z_row = [[0 for x in range(len(log_Xtrain_xtra[0]) - 1)] for y in range(1)]  # y + 1 index first then x so we swap ranges
    z_col = [[0 for x in range(1)] for y in range(len(log_Xtrain_xtra[0]))]  # y + 1 index first then x so we swap ranges

    X_tran = np.transpose(log_Xtrain_xtra)
    h_temp = np.matmul(X_tran,s_mat)
    h_k = np.matmul(h_temp,log_Xtrain_xtra)

    iden = np.identity(len(log_Xtrain_xtra[0]) - 1)
    new_reg_mat = np.concatenate((z_row,iden), axis=0)
    new_reg_mat = np.concatenate((z_col,new_reg_mat),axis=1)
    new_reg_mat = np.multiply(new_reg_mat,lamb[l])

    h_reg = np.add(h_k,new_reg_mat)
    return h_reg




    # MAIN

log_Xtrain = log_transform(Xtrain)
log_Xtest = log_transform(Xtest)

lamb = []
lamb1 = []
lamb2 = []

lamb1 = range(1,10,1) # index 0 - 8
lamb1 = list(map(int, lamb1))
lamb2 = range(10,101,5) # index 0 - 18
lamb2 = list(map(int, lamb2))
lamb = lamb1 + lamb2 # index 0 - 27
#print(lamb)




#w = w_bold[1 : len(Xtrain[0])]
Xtrain_ones = [[1 for x in range(1)] for y in range(len(Xtrain))] # y + 1 index first then x so we swap ranges, # declaration of 1d 'matrix' of ones
Xtest_ones = [[1 for x in range(1)] for y in range(len(Xtest))] # y + 1 index first then x so we swap ranges

log_Xtrain_xtra = [[0 for x in range(len(Xtrain[0]) + 1)] for y in range(len(Xtrain))] # y + 1 index first then x so we swap ranges, # declaration of 2d matrix of 0
log_Xtest_xtra = [[0 for x in range(len(Xtest[0]) + 1)] for y in range(len(Xtest))] # y + 1 index first then x so we swap ranges
#print(Xtrain_ones[3064][0])

log_Xtrain_xtra = np.concatenate((Xtrain_ones,log_Xtrain),axis=1)
log_Xtest_xtra = np.concatenate((Xtest_ones,log_Xtest),axis=1)


mu_vect = []
mu_temp = []


l = 0 # l = index of lamb list, index 0 - 27

s_id = list(np.identity(len(log_Xtrain_xtra))) # N X N identity matrix
s_id_temp = np.array(s_id)



def find_stat_w(log_Xtrain_xtra,ytrain,w_bold,s_id_temp,lamb,l):
    """Training the log. reg. model to find w that minimizes NLL """
    g_reg_norm = []
    iter = 0
    g_reg_n = 1 # initialize to any value > 10**-9
    while g_reg_n > 10**-9:
        #print(w_bold)
        mu_vect = mu_func(log_Xtrain_xtra, w_bold,0) # 0 is input because that argument is used in testing only in eval_log_reg func.
        mu_ones = [1]*(len(mu_vect))
        mu_temp = list(map(sub, mu_ones, mu_vect))
        a1 = np.array(mu_vect)
        b1 = np.array(mu_temp)
        mu_diag_vec = np.multiply(a1, b1)
        np.fill_diagonal(s_id_temp, mu_diag_vec)  # note: filled and stored back into s_id_temp
        s_mat = s_id_temp

        h_reg = hessian(log_Xtrain_xtra, s_mat, lamb, l)
        H_reg_inv = np.array(np.linalg.inv(h_reg),dtype=np.float64)
        g_reg = grad_reg(log_Xtrain_xtra, mu_vect, ytrain, w_bold, lamb, l)
        g_reg = np.array(g_reg,dtype=np.float64)

        w_k1 = w_bold - 1 * ( np.dot (H_reg_inv, g_reg))
        w_bold = w_k1

        g_reg_n = np.linalg.norm(g_reg)
        g_reg_norm.append(g_reg_n)
        iter = iter + 1

    w_min = w_bold
    return w_min

def eval_log_reg(test_data, w_min):

    ytest_classified = np.empty (( len(test_data) ))
    k = w_min[0]
    w_small = w_min[1:]
    p_y = mu_func(test_data, w_small, k)

    for i in range(0,len(p_y)):
        if p_y[i] > 0.5:
            ytest_classified[i] = 1
        else:
            ytest_classified[i] = 0

    ytest_classified = list(map(int, ytest_classified))
    return ytest_classified


# Training Error & Test Error

Train_err_rate = []
Test_err_rate = []

for l in range(0,len(lamb)):
    # eta_k = 1 constant learning rate
    l = 0
    w_bold = [0] * (len(Xtrain[0]) + 1)  # Initialize w_bold to zeros, (zero vector)
    w_bold = np.array(w_bold, dtype=np.float64)
    w_min = find_stat_w(log_Xtrain_xtra,ytrain,w_bold,s_id_temp,lamb,l)
    ytrain_classified = eval_log_reg(log_Xtrain, w_min)
    ytest_classified = eval_log_reg(log_Xtest, w_min)
    Train_err_rate.append( ErrorRate(ytrain,ytrain_classified) )
    Test_err_rate.append( ErrorRate(ytest,ytest_classified) )

"""
print(lamb[27])
print(Train_err_rate)
print(Test_err_rate)
# lamb = 1, Train_Er = 5.08972, Test_Er = 6.315104
# lamb = 10, Train_Er = 5.08972, Test_Er = 6.315104
# lamb = 100, Train_Er = 5.08972, Test_Er = 6.315104
"""
plt.plot(lamb,Train_err_rate , 'g')
plt.plot(lamb,Test_err_rate , 'r')
plt.ylabel('ytrain and ytest error (%)')
plt.xlabel('lambda')
plt.legend(['ytrain', 'ytest'], loc='lower right')
plt.show()




