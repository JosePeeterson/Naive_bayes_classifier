Please place spamdata.mat in the same folder

Run ques3 to plot train and test error vs lambda

It takes approximate 15 minutes to run this program.