print('Ques4 - Test data')

import sys
import math as m
import numpy as np
import operator
import matplotlib.pyplot as plt
from operator import sub
from operator import add
from numpy.linalg import inv

import scipy.io
mat = scipy.io.loadmat('spamData.mat')
Xtrain = mat['Xtrain']    # 2d array
ytrain = mat['ytrain']    # 1d array
Xtest = mat['Xtest']      # 2d array
ytest = mat['ytest']      # 1d array
#print(Xtrain[12])
ytrain = list(map(int, ytrain))
ytest = list(map(int, ytest))

    # FUNCTION DEFINITIONS

def log_transform(data):
    #log_data = np.where(data >= 0, log(data))
    mat = np.array(data) + 0.1
    log_data = np.log(mat)
    return log_data


def ErrorRate(ytest,ytest_classified):
    """This fucntion calculates error rate"""
    map_object = map(operator.sub, ytest,ytest_classified)
    subtracted_list = list(map_object)
    error = list(map(abs, subtracted_list))
    Er = ((sum(error))/len(ytest))*100
    return Er
# finds the euclidean norm between two vectors
def euc_norm(vec1, vec2):

    dist_temp = list(map(sub, vec1, vec2))
    dist = np.linalg.norm(dist_temp)

    return dist
# caculate distance between test point and every training point, ytrain is unused
def find_dist(Xtest_point,log_Xtrain,ytrain):
    dist_mag = []
    for i in range(0,len(log_Xtrain)):
        dist_mag.append(euc_norm(Xtest_point,log_Xtrain[i]))
    return dist_mag
# sorts the distance vector found in ascending order and returns the indices of the distances i.e. xtrain data point indices
def sort_dist_mag(dist_mag,k_vect,k):
    indices = []
    indices = sorted(range(len(dist_mag)), key=dist_mag.__getitem__)
    indices = [ indices[i] for i in range(0, (k_vect[k]))]
    return indices
# determines the test point class depending on which of more datapoint class is closer to it.
def clasify_tes_pnt(ytrain,indices, k_vect, k):
    sum_ones = 0
    sum_zeros = 0
    for i in indices:
        sum_ones = sum_ones + ytrain[i]

    sum_zeros = k_vect[k] - sum_ones
    if sum_zeros > sum_ones:
        return 0
    else:
        return 1


    # MAIN


log_Xtrain = log_transform(Xtrain)
log_Xtest = log_transform(Xtest)

# creates the K vector
k1 = list(np.arange(1,10,1)) # index 0 - 8
k2 = list(np.arange(10,101,5)) # 0 - 18
k_vect = k1 + k2 # index 0 - 27, index 0 - 8, 9 - 27
#print(k_vect[2]) # index 0 - 8, 9 - 27

dist_mag_test = []
dist_mag_train = []
indices_test = []
indices_train = []
ytest_classified = []
ytrain_classified = []
Er_train = []
Er_test = []
#k = 27 # index 0 - 27
#len(ytest)

# for each K find calculate the error in classifying test data
for k in range(0,len(k_vect)):
    for j in range(0,len(ytest)):
        dist_mag_test = find_dist(log_Xtest[j],log_Xtrain,ytrain)
        indices_test = sort_dist_mag(dist_mag_test, k_vect, k)
        ytest_classified.append( clasify_tes_pnt(ytrain, indices_test, k_vect, k) )
    Er_test.append(ErrorRate(ytest,ytest_classified))
    ytest_classified.clear()
    dist_mag_test.clear()
    indices_test.clear()
    print(k, Er_test)

# plot graph
plt.plot(k_vect,Er_test , 'r')
plt.ylabel('ytest error (%)')
plt.xlabel('K')
plt.show()



