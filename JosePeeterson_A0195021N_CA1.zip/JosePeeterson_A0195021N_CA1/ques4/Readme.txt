Please place spamdata.mat in the same folder

Run ques4_test to plot test error vs K

Run ques4_train to plot train error vs K

It takes approximate 2 hours to run each program.