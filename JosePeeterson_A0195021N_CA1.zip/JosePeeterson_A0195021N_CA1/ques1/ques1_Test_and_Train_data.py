print('Ques1')

import sys
import math as m
import numpy as np
import operator
import matplotlib.pyplot as plt

import scipy.io
mat = scipy.io.loadmat('spamData.mat')
Xtrain = mat['Xtrain']    # 2d array
ytrain = mat['ytrain']    # 1d array
Xtest = mat['Xtest']      # 2d array
ytest = mat['ytest']      # 1d array
#print(Xtrain[12])
ytrain = list(map(int, ytrain))
ytest = list(map(int, ytest))

    # FUNCTION DEFINTIONS
def Binarize(data):
    """This fucntion binarizes real numbers"""
    bin_data = np.where(data > 0, 1, 0)
    return bin_data

def ErrorRate(ytest,ytest_classified):
    """This fucntion calculates error rate"""
    map_object = map(operator.sub, ytest,ytest_classified)
    subtracted_list = list(map_object)
    error = list(map(abs, subtracted_list))
    Er = ((sum(error))/len(ytest))*100
    return Er

def Predict_new_emails(a, ytrain, ytest, Xtrain, Xtest):
    """This function predicts new email as spam or non spam"""
    # lambda max likelihood calculation
    ytrain = list(map(int, ytrain))
    ytest = list(map(int, ytest))
    Tot_emails = len(ytrain)
    Num_spam = sum(ytrain, 0)
    Num_NOT_spam = Tot_emails - Num_spam
    lamb_ML = Num_spam / Tot_emails
    # print(lamb_ML)

    b = a
    ytest_classified = []  # after classification of new emails
    cnt_ones_feat_cl = []  # stores either cnt_ones_feat_cl0 or cnt_ones_feat_cl1
    cnt_ones_feat_cl0 = []  # count ones for each feature in cl 0
    cnt_ones_feat_cl1 = []  # count ones for each feature in cl 1

    for feat in range(0, len(Xtrain[0])):
        cnt_ones = 0
        for s in range(0, len(Xtrain)):
            if (bin_Xtrain[s][feat] == 1 and ytrain[s] == 0):
                cnt_ones = cnt_ones + 1
        cnt_ones_feat_cl0.append(cnt_ones)

    for feat in range(0, len(Xtrain[0])):
        cnt_ones = 0
        for s in range(0, len(Xtrain)):
            if (bin_Xtrain[s][feat] == 1 and ytrain[s] == 1):
                cnt_ones = cnt_ones + 1
        cnt_ones_feat_cl1.append(cnt_ones)

    for n in range(0, len(ytest)):
        Num_cl = Num_NOT_spam
        cnt_ones_feat_cl = cnt_ones_feat_cl0
        for op_cl in range(0, 2):
            sum_lik_prob = 0
            for feat in range(0, len(Xtrain[0])):
                lik_prob = (cnt_ones_feat_cl[feat] + a) / (Num_cl + a + b)
                if (bin_Xtest[n][feat] == 0):
                    lik_prob = 1 - lik_prob
                sum_lik_prob = sum_lik_prob + m.log(lik_prob)

            if (op_cl == 0):
                Non_spam_prob = m.log(1 - lamb_ML) + sum_lik_prob
            else:
                spam_prob = m.log(lamb_ML) + sum_lik_prob
            Num_cl = Num_spam
            cnt_ones_feat_cl = cnt_ones_feat_cl1

        if (spam_prob >= Non_spam_prob):
            ytest_classified.append(1)
        else:
            ytest_classified.append(0)

    return ytest_classified
#    print(len(ytest_classified))



# MAIN PROGRAM

    #Binarize the data
bin_Xtrain = Binarize(Xtrain)
bin_Xtest = Binarize(Xtest)
#print(bin_Xtrain[12])


    #PREDICTION OF New Emails

alpha_beta = list(np.arange(0,100,0.5))
ytest_classified = []
Test_Er = []

for k in range(0, len(alpha_beta)):
    ytest_classified = Predict_new_emails(alpha_beta[k], ytrain, ytest, Xtrain, Xtest)
    Test_Er.append(ErrorRate(ytest, ytest_classified))

#print(Test_Er)

   #Binarize the data
#bin_Xtrain = Binarize(Xtrain)
bin_Xtest = bin_Xtrain
#print(bin_Xtrain[12])

#alpha_beta = list(np.arange(0,100,0.5))
ytrain_classified = []
Train_Er = []

for k in range(0, len(alpha_beta)):
    ytrain_classified = Predict_new_emails(alpha_beta[k], ytrain, ytrain, Xtrain, Xtrain)
    Train_Er.append(ErrorRate(ytrain, ytrain_classified))



plt.plot(alpha_beta, Train_Er, 'r')
plt.plot(alpha_beta,Test_Er, 'b')
plt.ylabel('Error rate/ %')
plt.xlabel('Alpha (0 - 100)')
plt.legend(['Training data', 'Testing data'], loc='upper left')
plt.show()



