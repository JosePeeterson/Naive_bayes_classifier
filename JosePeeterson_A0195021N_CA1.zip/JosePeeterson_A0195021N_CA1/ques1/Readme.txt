Please place a copy of spamData.mat in the folder

run ques1_Test_and_Train_Data to plot train and test error rate vs alpha

run ques1_Test_data to plot test error rate vs alpha

run ques1_Training_Data to plot train error rate vs alpha


It takes around 15 minutest to run each program.